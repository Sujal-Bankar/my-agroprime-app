import logo from './logo.svg';
import './App.css';
import BlogPage from './Components/BlogPage';

function App() {
  return (
    <div className="App">
      <>
      <BlogPage />
      
      
      </>
    </div>
  );
}

export default App;
